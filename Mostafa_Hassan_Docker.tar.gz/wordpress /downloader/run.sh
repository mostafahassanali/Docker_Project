
wget https://wordpress.org/latest.tar.gz
tar -xzvf latest.tar.gz --strip-component=1

